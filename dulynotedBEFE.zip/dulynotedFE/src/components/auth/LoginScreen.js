import React from 'react'
import { useForm } from '../../hooks/useForm';
import { useDispatch, useSelector } from 'react-redux'
import { login, startGoogleLogin, startLoginEmailPassword, startRegisterWitEmailPassword } from '../../actions/auth';
import { removeError, setError } from '../../actions/ui';

export const LoginScreen = () => {
    
    const dispatch = useDispatch();
    const { msgError, loading } = useSelector( state => state.ui );

    const [ formValues, handleInputChange, reset] = useForm({
        email: 'lucarojo123@gmail.com',
        password: '123123123123',
        nameReg: 'luca',
        usernameReg: 'lucarojo',
        emailReg: 'lucarojo123@gmail.com',
        passwordReg: '123123123123',
        password2Reg: '123123123123'
    })

    const { email, password, nameReg, usernameReg, emailReg, passwordReg, password2Reg} = formValues;

    const handleLoginSubmit = (e) => {
        e.preventDefault();
        dispatch( startLoginEmailPassword(email, password) );
    }

    const handleRegisterSubmit = (e) => {
        e.preventDefault();
        if( isFormValid() ){
            dispatch( startRegisterWitEmailPassword(emailReg, passwordReg, nameReg) )
        }
    }

    const isFormValid = () => {
        if ( nameReg.trim().length === 0 ){
            dispatch( setError('Name is required'))
            return false;
        }
        else if( usernameReg.trim().length === 0 ){
            console.log();
            dispatch( setError('Username is required'))
            return false;
        }
        else if( emailReg.trim().length === 0 ){
            dispatch( setError('Email is required'))
            return false;
        }
        else if( passwordReg !== password2Reg || passwordReg.length < 8 ){
            dispatch( setError('Password confirmation failed or is less than 8 characters'))
            return false;
        }
        dispatch( removeError() )
        return true;
    }

    const handleGoogleLogin = () => {
        dispatch( startGoogleLogin() );
    }
    
    return (
        <div className="container mt-5">
            <div className="row">
                <div className="col-sm"></div>
                <div className="col-sm">
                    <form onSubmit={ handleLoginSubmit }>
                        <h1 className="h3 mb-3 fw-normal">Please sign in</h1>
                        {/* <div className="alert alert-danger" role="alert">
                            A simple danger alert—check it out!
                        </div> */}
                        <input 
                            type="email" 
                            id="emailLogin"
                            name="email" 
                            className="form-control mt-1" 
                            placeholder="Email" 
                            autoComplete="off"
                            value={ email }
                            onChange={ handleInputChange }
                        />
                        <input 
                            type="password" 
                            id="passwordLogin" 
                            name="password"
                            className="form-control mt-1" 
                            placeholder="Password" 
                            value={ password }
                            onChange={ handleInputChange }
                        />
                        <button 
                            className="w-100 btn btn-lg btn-default mt-1" 
                            type="button"
                            name="google"
                            onClick={ handleGoogleLogin }
                        >
                            Sign in with Google
                        </button>
                        <button 
                            className="w-100 btn btn-lg btn-primary mt-1" 
                            type="submit"
                            name="submit"
                            disabled={ loading }
                        >
                            Sign in
                        </button>
                        <div className="d-grid gap-2 d-md-flex justify-content-md-center">
                            <button type="button" className="btn btn-outline-primary mt-1" data-bs-toggle="modal" data-bs-target="#registerModal" >Register</button>
                        </div>  
                    </form>
                </div>
                <div className="col-sm"></div>
            </div>
            <div>            
            <div className="modal fade" id="registerModal" tabIndex="-1" aria-labelledby="registerModalLabel" aria-hidden="true">
            <div className="modal-dialog">
                <div className="modal-content">
                <div className="modal-header">
                    <h5 className="modal-title" id="registerModalLabel">Register</h5>
                    <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div className="modal-body">
                <form onSubmit={ handleRegisterSubmit }>
                    {
                        msgError && (
                            <div className="alert alert-danger" role="alert">
                                { msgError }
                            </div>
                        )
                    }
                        
                        <input 
                            type="text" 
                            id="nameReg"
                            name="nameReg" 
                            className="form-control mt-1" 
                            placeholder="Name" 
                            autoComplete="off"
                            value={ nameReg }
                            onChange={ handleInputChange }
                        />
                        <input 
                            type="text" 
                            id="usernameReg"
                            name="usernameReg" 
                            className="form-control mt-1" 
                            placeholder="Username" 
                            autoComplete="off"
                            value={ usernameReg }
                            onChange={ handleInputChange }
                        />
                        <input 
                            type="email" 
                            id="emailReg"
                            name="emailReg" 
                            className="form-control mt-1" 
                            placeholder="Email" 
                            autoComplete="off"
                            value={ emailReg }
                            onChange={ handleInputChange }
                        />
                       <input 
                            type="password" 
                            id="passwordReg" 
                            name="passwordReg"
                            className="form-control mt-1" 
                            placeholder="Password" 
                            value={ passwordReg }
                            onChange={ handleInputChange }
                        />
                        <input 
                             type="password" 
                             id="password2Reg" 
                             name="password2Reg"
                             className="form-control mt-1" 
                             placeholder="Password" 
                             value={ password2Reg }
                             onChange={ handleInputChange }
                            />
                        <button type="submit" className="btn btn-primary">Register</button>
                    </form>
                </div>
                <div className="modal-footer">
                    <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </div>
                </div>
            </div>
            </div>
        </div>
        </div>
    )
}
