import React from 'react'

export const PublicNotesScreen = () => {
    return (
        <div>
            <h1>public notes</h1>
        </div>
    )
}
