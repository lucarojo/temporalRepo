import React from 'react'

export const NotepadScreen = () => {
    return (
        <div>
            <h1>Notepad</h1>
        </div>
    )
}
