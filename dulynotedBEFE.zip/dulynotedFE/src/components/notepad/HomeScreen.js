import React from 'react'
import { NoteCard } from './notepad-comps/NoteCard'

export const HomeScreen = () => {

    const noteData = {
        noteid: 1, 
        title: 'Temporal note', 
        date: '02/08/2021', 
        text: 'This is only a test note it does not contain ', 
        folderName: 'Test',
        folderAddr: '/asdfasdf/Test'
    }

    return (
        <div className="container mt-3">
            <h1>DulyNoted Notes:</h1>
            <h3>My recent notes</h3>
            <div className="row">
                <div className="col-sm">
                    <NoteCard noteid={ noteData.noteid } title={ noteData.title} date={ noteData.date } text={ noteData.text } folderName={ noteData.folderName } folderAddr={ noteData.folderAddr} />
                </div>
                <div className="col-sm">
                    <NoteCard noteid={ noteData.noteid } title={ noteData.title} date={ noteData.date } text={ noteData.text } folderName={ noteData.folderName } folderAddr={ noteData.folderAddr} />
                </div>
                <div className="col-sm">
                    <NoteCard noteid={ noteData.noteid } title={ noteData.title} date={ noteData.date } text={ noteData.text } folderName={ noteData.folderName } folderAddr={ noteData.folderAddr} />
                </div>
                <div className="col-sm">
                    <NoteCard noteid={ noteData.noteid } title={ noteData.title} date={ noteData.date } text={ noteData.text } folderName={ noteData.folderName } folderAddr={ noteData.folderAddr} />
                </div>
            </div>
            <br/>
            <h3>Recent notes shared with me.</h3>
            <div className="row">
                <div className="col-sm">
                    <NoteCard noteid={ noteData.noteid } title={ noteData.title} date={ noteData.date } text={ noteData.text } folderName={ noteData.folderName } folderAddr={ noteData.folderAddr} />
                </div>
                <div className="col-sm">
                    <NoteCard noteid={ noteData.noteid } title={ noteData.title} date={ noteData.date } text={ noteData.text } folderName={ noteData.folderName } folderAddr={ noteData.folderAddr} />
                </div>
                <div className="col-sm">
                    <NoteCard noteid={ noteData.noteid } title={ noteData.title} date={ noteData.date } text={ noteData.text } folderName={ noteData.folderName } folderAddr={ noteData.folderAddr} />
                </div>
                <div className="col-sm">
                    <NoteCard noteid={ noteData.noteid } title={ noteData.title} date={ noteData.date } text={ noteData.text } folderName={ noteData.folderName } folderAddr={ noteData.folderAddr} />
                </div>
            </div>
            <br/>
            <h3>My recent public notes</h3>
            <div className="row">
                <div className="col-sm">
                    <NoteCard noteid={ noteData.noteid } title={ noteData.title} date={ noteData.date } text={ noteData.text } folderName={ noteData.folderName } folderAddr={ noteData.folderAddr} />
                </div>
                <div className="col-sm">
                    <NoteCard noteid={ noteData.noteid } title={ noteData.title} date={ noteData.date } text={ noteData.text } folderName={ noteData.folderName } folderAddr={ noteData.folderAddr} />
                </div>
                <div className="col-sm">
                    <NoteCard noteid={ noteData.noteid } title={ noteData.title} date={ noteData.date } text={ noteData.text } folderName={ noteData.folderName } folderAddr={ noteData.folderAddr} />
                </div>
                <div className="col-sm">
                    <NoteCard noteid={ noteData.noteid } title={ noteData.title} date={ noteData.date } text={ noteData.text } folderName={ noteData.folderName } folderAddr={ noteData.folderAddr} />
                </div>
            </div>
            <br/>
        </div>
    )
}
