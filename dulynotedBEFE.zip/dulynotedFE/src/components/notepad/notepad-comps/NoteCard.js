import React from 'react'

export const NoteCard = ({noteid,title,date,text,folderName,folderAddr}) => {
    return (
        <>
            <div className="card">
                <div className="card-body">
                    <h5 className="card-title">{ title }</h5>
                    <h6 className="card-subtitle mb-2 text-muted">{ date }</h6>
                    <p className="card-text">{ text }...</p>
                    <a href="" className="card-link">Edit</a>
                    <a href="" className="card-link">Go to folder { folderName }</a>
                </div>
            </div>
        </>
    )
}
