import React from 'react'

export const MyNotesScreen = () => {
    return (
        <div>
            <h1>my notes</h1>
        </div>
    )
}
