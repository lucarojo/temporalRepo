import firebase from "firebase/app";
import 'firebase/firestore';
import 'firebase/auth'

const firebaseConfig = {
        apiKey: "AIzaSyA_jCepjeolSFNFuyxZORV_l6JI8WsRauw",
        authDomain: "notepad-app-a0f26.firebaseapp.com",
        projectId: "notepad-app-a0f26",
        storageBucket: "notepad-app-a0f26.appspot.com",
        messagingSenderId: "756733831748",
        appId: "1:756733831748:web:7d50c7e983353346616a11",
        measurementId: "G-LP1WB9LVCS"
    };

firebase.initializeApp(firebaseConfig);

const db = firebase.firestore();
const googleAuthProvider = new firebase.auth.GoogleAuthProvider();

export {
    db,
    googleAuthProvider,
    firebase
}