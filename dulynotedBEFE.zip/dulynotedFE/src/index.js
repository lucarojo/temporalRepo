import React from 'react';
import ReactDOM from 'react-dom';
import { NotepadApp } from './NotepadApp';

ReactDOM.render(
    <NotepadApp />,
  document.getElementById('root')
);
