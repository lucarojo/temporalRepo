const jwt = require('jsonwebtoken');

const generateJWT = (userid, name, username) => {
    return new Promise(( resolve, reject ) => {
        const payload = { userid, name, username };
        jwt.sign(payload, process.env.SECRET_JWT_SEED, {
            expiresIn: '2h'
        }, (err, token)=> {
            if(err){
                console.log(err);
                reject('Couldnt generate web token');
            }
            resolve( token );
        })
    })
}

module.exports = {
    generateJWT
}