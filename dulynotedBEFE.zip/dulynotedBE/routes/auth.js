/*
    host + /api/auth
*/

const { Router } = require('express');
const router = Router();
const { check } = require('express-validator')
const { fieldValidator } = require('../middlewares/field-validator')
const { createUser, userLogin, renewToken } = require("../controllers/auth")
const { jwtValidator } = require('../middlewares/jwt-validator')

router.post(
    '/register', 
    [
        //middlewares
        check('name', 'Name is required.').not().isEmpty(),
        check('username', 'Username is required.').not().isEmpty(),
        check('email', 'Email is required.').not().isEmpty(),
        check('email', 'Email is not valid.').isEmail(),
        check('password', 'Password is required.').not().isEmpty(),
        check('password', 'Password is not valid').isLength({ min: 8 }),
        fieldValidator
    ], 
    createUser
);

router.post(
    '/', 
    [
        check('email', 'Email is required.').not().isEmpty(),
        check('email', 'Email is not valid.').isEmail(),
        check('password', 'Password is required.').not().isEmpty(),
        check('password', 'Password is not valid.').isLength({ min: 8 }),
        fieldValidator
    ],
    userLogin
);

router.get(
    '/renew',
    jwtValidator,
    renewToken
);

module.exports = router;