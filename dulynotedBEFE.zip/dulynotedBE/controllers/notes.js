const { response } = require('express');
const Note = require('../models/Note');

const getNotes = async( req, res = response ) => {

    const notes = await Note.find()
                                .populate('userid', 'name username');

    res.json({
        ok: true,
        notes
    });
}
const createNote = async( req, res = response ) => {

    const note = new Note( req.body );

    try {
        note.userid = req.userid;
        const noteDB = await note.save();

        res.json({
            ok: true,
            note: noteDB
        });
    } catch (error) {
        console.log(error);
        res.status(500).json({
            ok: false,
            msg: 'Please contact the administrator'
        });
    }
}
const updateNote = async( req, res = response ) => {

    const noteid = req.params.id;
    const userid = req.userid;

    try {
        
        const note = await Note.findById( noteid );

        if( !note ){
            return res.status(404).json({
                ok: false,
                msg: 'Note doesnt exists'
            })
        }
        
        if( note.userid.toString() !== userid ){
            return res.status(401).json({
                ok: false,
                msg: 'User cannot edit this note'
            })
        }

        const newNote = {
            ...req.body,
            userid: userid
        }

        const updatedNote = await Note.findByIdAndUpdate( noteid, newNote, { new: true} )

        res.json({
            ok: true,
            note: updatedNote
        })

    } catch (error) {
        console.log(error);
        res.status(500).json({
            ok: false,
            msg: 'Please contact the administrator'
        });
    }
}
const deleteNote = async( req, res = response ) => {
    
    const noteid = req.params.id;
    const userid = req.userid;
    
    try {
        const note = await Note.findById( noteid );

        if( !note ){
            return res.status(404).json({
                ok: false,
                msg: 'Note doesnt exists'
            })
        }
        
        if( note.userid.toString() !== userid ){
            return res.status(401).json({
                ok: false,
                msg: 'User cannot delete this note'
            })
        }

        await Note.findByIdAndDelete( noteid )

        res.json({
            ok: true
        });

    } catch (error) {
        console.log(error);
        res.status(500).json({
            ok: false,
            msg: 'Please contact the administrator'
        });
    }
}

module.exports = {
    getNotes,
    createNote,
    updateNote,
    deleteNote
}