const { response } = require('express')
const bcrypt = require("bcryptjs")
const User = require('../models/User')
const { generateJWT } = require('../helpers/jwt')

const createUser = async(req, res = response) => {

    const { email, password } = req.body;

    try {
        let user = await User.findOne({ email });
        if( user ){
            return res.status(400).json({
                ok: false,
                msg: 'User already exists with the email provided.'
            });
        }

        user = new User(req.body);
        //password encryption
        const salt = bcrypt.genSaltSync();
        user.password = bcrypt.hashSync( password, salt);

        await user.save();

        //Token
        const token = await generateJWT(user.id, user.name, user.username);

        res.status(201).json({
            ok: true,
            uid: user.id,
            name: user.name,
            username: user.username,
            token
        });
    } catch (error) {
        console.log(error);
        res.status(500).json({
                ok: false,
                msg: 'Please contact the administrator.'
        });
    }

}

const userLogin = async(req , res = response) => {

    const { email, password } = req.body

    try {
        let user = await User.findOne({ email });
        if( !user ){
            return res.status(400).json({
                ok: false,
                msg: 'User or password incorrect.u'
            });
        }

        const validPassword = bcrypt.compareSync( password, user.password );
        if( !validPassword ){
            return res.status(400).json({
                ok: false,
                msg: 'User or password incorrect.p'
            });
        }

        //Token
        const token = await generateJWT(user.id, user.name, user.username);

        res.status(200).json({
            ok: true,
            uid: user.id,
            name: user.name,
            username: user.username,
            token
        });

    } catch (error) {
        console.log(error);
        res.status(500).json({
            ok: false,
            msg: 'Please contact the administrator.'
        });
    }
}

const renewToken = async (req, res) => {

    const { uid, name, username } = req;

    const token = await generateJWT(uid, name, username);

    res.json({
        ok: true,
        token
    })
}

module.exports = { 
    createUser,
    userLogin,
    renewToken,
}