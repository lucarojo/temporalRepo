const mongoose = require('mongoose');

const dbCnx = async () => {
    try {
        await mongoose.connect(process.env.DB_CNX, {
            useNewUrlParser: true, 
            useUnifiedTopology: true,
            useCreateIndex: true
        });

        console.log('DB Online');

    } catch (error) {
        console.log(error);
        throw new Error('Error initializing database')
    }
}

module.exports = {
    dbCnx
}