/*
    host + /api/notes
*/

const { Router } = require('express');
const router = Router();
const { check } = require('express-validator');
const { isDate } = require('../helpers/isDate');
const { fieldValidator } = require("../middlewares/field-validator");
const { jwtValidator } = require('../middlewares/jwt-validator');
const { getNotes, createNote, updateNote, deleteNote } = require('../controllers/notes');

//Validations
router.use( jwtValidator );

//Get events
router.get('/', getNotes );

//Create note
router.post(
    '/', 
    [
        check('title', 'Title is required').not().isEmpty(),
        check('date', 'Date is required').custom( isDate ),
        check('idparentfolder', 'Parent folder is required').not().isEmpty(),
        check('idnotetype', 'Note type is required').not().isEmpty(),
        fieldValidator
    ],
    createNote 
);

//Update note
router.put(
    '/:id', 
    [
        check('title', 'Title is required').not().isEmpty(),
        check('date', 'Date is required').custom( isDate ),
        check('idparentfolder', 'Parent folder is required').not().isEmpty(),
        check('idnotetype', 'Note type is required').not().isEmpty(),
        fieldValidator
    ],
    updateNote
);

//Delete event
router.delete('/:id', deleteNote );

module.exports = router;