import React from 'react'
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link,
    Redirect
  } from "react-router-dom";
import { HomeScreen } from '../components/notepad/HomeScreen';
import { MyNotesScreen } from '../components/notepad/MyNotesScreen';
import { NotepadScreen } from '../components/notepad/NotepadScreen';
import { EditNotepadScreen } from '../components/notepad/EditNotepadScreen';
import { PublicNotesScreen } from '../components/notepad/PublicNotesScreen';
import { SharedNotesScreen } from '../components/notepad/SharedNotesScreen';
import { NavBar } from '../components/ui/NavBar';
import { ProfileRouter } from './ProfileRouter';

export const NotepadRouter = () => {
    return (
        <Router>
            <NavBar />
            <div className="container">
                <Switch>
                    <Route
                        path="/profile"
                        component={ ProfileRouter }
                    />
                     <Route
                        exact
                        path="/"
                        component={ HomeScreen }
                    />
                    <Route
                        exact
                        path="/notepad"
                        component={ NotepadScreen }
                    />
                    <Route 
                        exact
                        path="/editnote/:id"
                        component={ EditNotepadScreen }
                    />
                    <Route
                        exact
                        path="/mynotes"
                        component={ MyNotesScreen }
                    />
                    <Route
                        exact
                        path="/sharednotes"
                        component={ SharedNotesScreen }
                    />
                    <Route
                        exact
                        path="/publicnotes"
                        component={ PublicNotesScreen }
                    />
                    <Redirect to="/" />
                </Switch>
            </div>
        </Router>
    )
}
