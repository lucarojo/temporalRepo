import React, { useEffect, useState } from 'react'
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link,
    Redirect
  } from "react-router-dom";
import { useDispatch, useSelector } from 'react-redux'
import { LoginScreen } from '../components/auth/LoginScreen';
import { NotepadRouter } from './NotepadRouter';
import { PrivateRoute } from './PrivateRoute';
import { PublicRoute } from './PublicRoute';
import { startChecking } from '../actions/auth';
import { LoadingScreen } from '../components/ui/LoadingScreen';

export const AppRouter = () => {
    
    const dispatch = useDispatch();
    const { checking, userid } = useSelector(state => state.auth)
    useEffect(() => {
        
        dispatch( startChecking() );

    }, [dispatch])

    if( checking ){
        return(
            <LoadingScreen />
        )
    }
    return (
        <Router>
            <div>
                <Switch>
                    <PublicRoute 
                        exact 
                        path="/login" 
                        component={ LoginScreen } 
                        isAuthenticated={ !!userid }
                    />
                    <PrivateRoute 
                        path="/" 
                        component={ NotepadRouter } 
                        isAuthenticated={ !!userid }
                    />
                </Switch>
            </div>
        </Router>
    )
}
