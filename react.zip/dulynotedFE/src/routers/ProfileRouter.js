import React from 'react'
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Redirect
  } from "react-router-dom";
import { ProfileScreen } from '../components/profile/ProfileScreen'
import { SettingsScreen } from '../components/profile/SettingsScreen'

export const ProfileRouter = () => {
    return (
        <Router>
            <div>
                <Switch>
                    <Route 
                        exact
                        path="/profile/me"
                        component={ ProfileScreen}
                    />
                    <Route
                        exact
                        path="/profile/settings"
                        component={ SettingsScreen }
                    />
                    <Redirect to="/profile/me" />
                </Switch>
            </div>
        </Router>
    )
}
