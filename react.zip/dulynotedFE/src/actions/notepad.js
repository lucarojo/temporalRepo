import { fetchWithToken } from "../helpers/fetch"
import { types } from "../types/types"
import swal from 'sweetalert2'
import { useHistory } from "react-router-dom"

export const notepadStartNewNote = ( note, history ) => {
    return async( dispatch ) => {
        try {
            const resp = await fetchWithToken( 'notes', note, 'POST');
            const body = await resp.json();

            swal.fire({
                title: 'Success',
                text: 'Note saved succesfully',
                icon: 'success',
                timer: 3000,
                willClose: () => {
                    history.push('/mynotes');
                  }
            });
        } catch (error) {
            console.log(error);
            swal.fire('Error', 'Error guardando la nota', 'error');
        }
    }
}

const notepadNewNote = ( note ) => ({
    type: types.notepadNewNote,
    payload: note
})

export const notepadStartLoading = () => {
    return async( dispatch ) => {
        try {
            
            const resp = await fetchWithToken( 'notes' );
            const body = await resp.json();

            const notes = body.notes;
            //console.log(notes);
            dispatch( notepadNotesLoaded( notes ) );

        } catch (error) {
            console.log(error);
        }
    }
}

const notepadNotesLoaded = ( notes ) => ({
    type: types.notepadNotesLoaded,
    payload: notes
})

export const notepadStartGetNotepadById = ( noteid ) => {
    return async( dispatch ) => {
        try {
            
            const resp = await fetchWithToken( 'notes' );
            const body = await resp.json();

            const note = body.notes.find((note) => note.id === noteid);
            // console.log(note);
            dispatch( notepadGetNotepadById( note ) );

        } catch (error) {
            console.log(error);
        }
    }
}

const notepadGetNotepadById = ( note ) => ({
    type: types.notepadGetNoteById,
    payload: note
})