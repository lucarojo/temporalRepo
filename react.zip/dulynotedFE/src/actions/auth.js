import { firebase, googleAuthProvider } from "../firebase/firebaseConfig";
import { fetchWOToken, fetchWithToken } from "../helpers/fetch";
import { types } from "../types/types"
import { finishLoading, startLoading } from "./ui";
import swal from 'sweetalert2';

export const startLoginEmailPassword = (email, password) => {
    return ( dispatch ) => {
        dispatch(startLoading())
        firebase.auth().signInWithEmailAndPassword(email, password)
            .then( ({user}) => {
                dispatch( login( user.uid, user.displayName ))
                dispatch(finishLoading())
            })
            .catch(e => {
                console.log(e);
                dispatch(finishLoading())
            })
    }
}

export const startRegisterWitEmailPassword = (emailReg, passwordReg, nameReg) => {
    return ( dispatch ) => {
        firebase.auth().createUserWithEmailAndPassword(emailReg, passwordReg)
            .then( async ({ user }) => {
                await user.updateProfile({ displayName: nameReg});
                dispatch( login(
                    user.uid,
                    user.displayName
                ))
                console.log(user.uid, user.displayName);
            }).catch(e => console.log(e))
    }
}

export const startGoogleLogin = () => {
    return ( dispatch ) => {
        firebase.auth().signInWithPopup( googleAuthProvider )
            .then( ({ user }) => {
                dispatch( login(
                    user.uid,
                    user.displayName
                ))
            })
    }
}

export const startRegister = ( name, username, email, password) => {
    return async(dispatch) => {
        const resp = await fetchWOToken( 'auth/register', { name, username, email, password }, 'POST');
        const body = await resp.json();

        if( body.ok ){
            localStorage.setItem('token', body.token);
            localStorage.setItem('token-init-date', new Date().getTime());

            dispatch( login({
                userid: body.userid,
                name: body.name,
                username: body.username
            }))
        } else {
            swal.fire('Error', body.msg, 'error')
        }
    }
}

export const startLogin = ( email, password ) => {
    return async( dispatch ) => {
        const resp = await fetchWOToken( 'auth', { email, password }, 'POST');
        const body = await resp.json();
        
        if( body.ok ){
            localStorage.setItem('token', body.token);
            localStorage.setItem('token-init-date', new Date().getTime());

            dispatch( login({
                userid: body.userid,
                name: body.name,
                username: body.username
            }))
        } else {
            swal.fire('Error', body.msg, 'error')
        }
    }
}

export const login = ( user ) => ({
    type: types.authLogin,
    payload: user
})

export const startLogout = () => {
    return (dispatch) => {
        localStorage.clear();
        dispatch(logout());
    }
}

export const logout = () => ({
    type: types.authLogout
})

export const startChecking = () => {
    return async(dispatch) => {
        const resp = await fetchWithToken( 'auth/renew' );
        const body = await resp.json();

        if( body.ok ){
            localStorage.setItem('token', body.token);
            localStorage.setItem('token-init-date', new Date().getTime());

            dispatch( login({
                userid: body.userid,
                name: body.name,
                username: body.username
            }))
        } else {
            dispatch( checkingFinish() )
        }
    }
}

export const checkingFinish = () => ({
    type: types.authCheckingFinish
})