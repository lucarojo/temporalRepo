export const types = {
    authCheckingFinish: '[Auth] Finish checking login state',
    authStartLogin: '[Auth] Start login',
    authLogin: '[Auth] Login',
    authStartRegister: '[Auth] Start register',
    authStartTokenRenew: '[Auth] Start token renew',
    authLogout: '[Auth] Logout',

    uiSetError: '[UI] Set Error',
    uiRemoveError: '[UI] Remove Error',
    
    uiStartLoading: '[UI] Start loading',
    uiFinishLoading: '[UI] Finish loading',

    notepadStartNewNote: '[Notepad] Start Add new',
    notepadNewNote: '[Notepad] New note',
    notepadEditNote: '[Notepad] Edit note',
    notepadDeleteNote: '[Notepad] Delete note',
    notepadNotesLoaded: '[Notepad] Notes loaded',
    notepadStartGetNotepadById: '[Notepad] Start note by id',
    notepadGetNoteById: '[Notepad] Get note by id',
}