import { types } from '../types/types'

const initialState = {
    notes: [],
    selectedNote: {

    }
}

export const notepadReducer = ( state = initialState, action ) => {
    switch ( action.type ) {
        case types.notepadNotesLoaded:
            return {
                ...state,
                notes: [ ...action.payload ],
                selectedNote: {}
            }
        case types.notepadGetNoteById:
            return {
                ...state,
                selectedNote: action.payload
            }
        default:
            return state
    }
}