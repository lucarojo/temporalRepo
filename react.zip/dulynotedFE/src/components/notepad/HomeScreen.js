import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { notepadStartLoading } from '../../actions/notepad';
import { NoteCard } from './notepad-comps/NoteCard'

export const HomeScreen = () => {

    const dispatch = useDispatch();
    useEffect(() => {
        dispatch( notepadStartLoading() )
    }, [dispatch])

    const { notes } = useSelector(state => state.notepad)

    return (
        <div className="container mt-3">
            <h1>DulyNoted Notes:</h1>
            <h3>My recent notes</h3>
            <div className="row">
                {
                    ( notes !== undefined ) &&
                    notes.reverse().slice(0, 4).map( note => {
                        return <div className="col-sm" key={ note.id }>
                            <NoteCard 
                                noteid={ note.id }
                                { ...note }
                            />
                        </div>
                    })
                }
            </div>
            <br/>
            <h3>Recent notes shared with me.</h3>
            <div className="row">
                {
                    // ( notes !== undefined ) &&
                    // notes.map( note => {
                    //     return <div className="col-sm">
                    //         <NoteCard 
                    //             key={ note.noteid + 1}
                    //             { ...note }
                    //         />
                    //     </div>
                    // })
                }
            </div>
            <br/>
            <h3>My recent public notes</h3>
            <div className="row">
                {
                    // ( notes !== undefined ) &&
                    // notes.map( note => {
                    //     return <div className="col-sm">
                    //         <NoteCard 
                    //             key={ note.noteid + 2}
                    //             { ...note }
                    //         />
                    //     </div>
                    // })
                }
            </div>
            <br/>
        </div>
    )
}
