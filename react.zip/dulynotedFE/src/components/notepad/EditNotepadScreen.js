import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { useHistory, useParams } from 'react-router-dom';
import { notepadStartGetNotepadById, notepadStartNewNote } from '../../actions/notepad';
import { useForm } from '../../hooks/useForm';

export const EditNotepadScreen = () => {

    const dispatch = useDispatch();
    const history = useHistory();
    const { id } = useParams();
    
    const { selectedNote } = useSelector(state => state.notepad)

    // useEffect(() => {
    //     dispatch( notepadStartGetNotepadById( id ) )
    // }, [dispatch])

    console.log(selectedNote);
    
    let [formValues, handleInputChange, reset] = useForm( selectedNote );
    let { title, date, text } = formValues;



    const handleSubmit = (e) => {
        e.preventDefault();

        dispatch( notepadStartNewNote( {
            ...formValues,
            date: Date.parse(date),
            idparentfolder: "60230cd54f70f621444fbd56",
            idnotetype: "60230cd54f70f621444fbd55",
        }, history ))
    }

    return (
        <div className="container border rounded p-2 mt-2">
            <form>
                <div className="mb-3">
                    <label htmlFor="title" className="form-label">Note title</label>
                    <input 
                        type="text" 
                        className="form-control" 
                        id="title" 
                        name="title" 
                        placeholder="New note"
                        value={ title }
                        onChange={ handleInputChange }
                    />
                </div>
                <div className="mb-3">
                    <label htmlFor="date" className="form-label">Creation date</label>
                    <input 
                        type="text"
                        className="form-control"
                        id="date"
                        name="date"
                        placeholder=""
                        // disabled={ true }
                        value={ date }
                        onChange={ handleInputChange }
                    />
                </div>
                <div className="mb-3">
                    <label htmlFor="text" className="form-label">Note</label>
                    <textarea 
                        className="form-control" 
                        id="text" 
                        name="text"
                        rows="3"
                        placeholder="New note"
                        value={ text }
                        onChange={ handleInputChange }
                    >
                    </textarea>
                </div>
                <div className="d-grid gap-2 d-md-flex justify-content-md-end">
                    <button
                        type="button"
                        className="btn btn-danger mr-1"
                        id="cancel"
                        name="cancel"
                    >
                        Cancel
                    </button>
                    <button
                        type="button"
                        className="btn btn-success"
                        id="submit"
                        name="submit"
                        type="submit"
                        onClick={ handleSubmit }
                    >
                        Save
                    </button>
                </div>
            </form>
        </div>
    )
}
