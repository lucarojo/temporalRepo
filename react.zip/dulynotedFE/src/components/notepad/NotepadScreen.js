import React from 'react'
import { useDispatch } from 'react-redux';
import { useHistory } from 'react-router-dom';
import { notepadStartNewNote } from '../../actions/notepad';
import { useForm } from '../../hooks/useForm';

export const NotepadScreen = () => {

    const dispatch = useDispatch();
    const history = useHistory();

    const initialForm = {
        title: 'New note',
        date: new Date().toLocaleDateString(),
        text: 'New note text'
    }


    const [formValues, handleInputChange, reset] = useForm(initialForm);
    const { title, date, text } = formValues;

    const handleSubmit = (e) => {
        e.preventDefault();

        dispatch( notepadStartNewNote( {
            ...formValues,
            date: Date.parse(date),
            idparentfolder: "60230cd54f70f621444fbd56",
            idnotetype: "60230cd54f70f621444fbd55",
        }, history ))
    }

    return (
        <div className="container border rounded p-2 mt-2">
            <form>
                <div className="mb-3">
                    <label htmlFor="title" className="form-label">Note title</label>
                    <input 
                        type="text" 
                        className="form-control" 
                        id="title" 
                        name="title" 
                        placeholder="New note"
                        value={ title }
                        onChange={ handleInputChange }
                    />
                </div>
                <div className="mb-3">
                    <label htmlFor="date" className="form-label">Creation date</label>
                    <input 
                        type="text"
                        className="form-control"
                        id="date"
                        name="date"
                        placeholder=""
                        // disabled={ true }
                        value={ date }
                        onChange={ handleInputChange }
                    />
                </div>
                <div className="mb-3">
                    <label htmlFor="text" className="form-label">Note</label>
                    <textarea 
                        className="form-control" 
                        id="text" 
                        name="text"
                        rows="3"
                        placeholder="New note"
                        value={ text }
                        onChange={ handleInputChange }
                    >
                    </textarea>
                </div>
                <div className="d-grid gap-2 d-md-flex justify-content-md-end">
                    <button
                        type="button"
                        className="btn btn-danger mr-1"
                        id="cancel"
                        name="cancel"
                    >
                        Cancel
                    </button>
                    <button
                        type="button"
                        className="btn btn-success"
                        id="submit"
                        name="submit"
                        type="submit"
                        onClick={ handleSubmit }
                    >
                        Save
                    </button>
                </div>
            </form>
        </div>
    )
}
