import React from 'react'
import { useDispatch } from 'react-redux'
import { useHistory } from 'react-router-dom'
import { notepadStartGetNotepadById } from '../../../actions/notepad';

export const NoteCard = ({noteid,title,date,text,folderName,folderAddr}) => {

    const dispatch = useDispatch();
    const history = useHistory();

    const handleEditNote = (e) => {
        e.preventDefault()
        dispatch( notepadStartGetNotepadById( noteid ))
        history.push(`/editnote/${ noteid }`);
    }

    return (
        <>
            <div className="card">
                <div className="card-body">
                    <h5 className="card-title">{ title }</h5>
                    <h6 className="card-subtitle mb-2 text-muted">{ date }</h6>
                    <p className="card-text">{ text }...</p>
                    <a href="" onClick={ handleEditNote } className="card-link">Edit</a>
                    <a href="" className="card-link">Go to folder { folderName }</a>
                </div>
            </div>
        </>
    )
}
