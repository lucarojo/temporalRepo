import React from 'react'

export const SharedNotesScreen = () => {
    return (
        <div>
            <h1>shared notes</h1>
        </div>
    )
}
