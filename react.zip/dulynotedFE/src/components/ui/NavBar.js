import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { startLogout } from '../../actions/auth'

export const NavBar = () => {
    
    const dispatch = useDispatch()
    const handleLogout = () => {
        dispatch( startLogout() );
    }

    const { name } = useSelector(state => state.auth)
    
    return (
        <div>
            <nav className="navbar navbar-expand-lg navbar-light bg-light">
                <div className="container-fluid">
                    <a className="navbar-brand" href="#">DulyNoted</a>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                            <li className="nav-item">
                                <a className="nav-link" href="/">Home</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" href="/notepad">New note</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" href="/mynotes">My notes</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" href="/sharednotes">Shared notes</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" href="/publicnotes">Comunity</a>
                            </li>
                            <li className="nav-item dropdown">
                                <a className="nav-link dropdown-toggle" href="" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    Profile
                                </a>
                                <ul className="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <li><a className="dropdown-item" href="/profile/me">Profile</a></li>
                                    <li><a className="dropdown-item" href="/profile/settings">Settings</a></li>
                                    <li><hr className="dropdown-divider" /></li>
                                    <li><a className="dropdown-item" onClick={ handleLogout }>Logout</a></li>
                                </ul>
                            </li>
                        </ul>
                        <span className="navbar-text">
                            Welcome { name }
                        </span>
                    </div>
                </div>
            </nav>
        </div>
    )
}
