import React from 'react'

export const LoadingScreen = () => {
    return (
        <div>
            <h1>Loading</h1>
        </div>
    )
}
