import React from 'react'

export const ProfileScreen = () => {
    return (
        <div>
            <h1>profile</h1>
        </div>
    )
}
