import React from 'react'

export const SettingsScreen = () => {
    return (
        <div>
            <h1>Settings</h1>
        </div>
    )
}
